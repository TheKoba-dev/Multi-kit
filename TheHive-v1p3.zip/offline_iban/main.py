from lib_iban import *
import os 
while True:
    print ("=============================")
    print ("Çevrimdışı iban çözümleyici\n")
    raw_input_1 = input ("ibn giriniz -> ")
    
    a = country_detect(raw_input_1)


    raw_input_1_leng = len(raw_input_1)
    standart_leng = a[1]
    if raw_input_1_leng == standart_leng:
    
        print (f"Ülke: {a[0]}\n")
        print (f"Max iban uzunluğu: {a[1]}\n")
        print (f"SEPA desteği: {a[2]}\n")
        print (f"Hesap kontrolu: {a[2]}\n")
        print (f"Şube kontrolu: {a[4]}\n")
        print (f"Ülke kodu: {a[5]}")
    elif raw_input_1_leng > standart_leng:
    
        print ("İban olması gerekenden uzun...!\n")
        print ("Bu iban geçersizdir...!")
    elif raw_input_1_leng < standart_leng:
    
        print ("İban olması gerekenden kısa...!\n")
        print ("Bu iban geçersizdir...!")
    else:
        print ("Bilinmeyen hata...!")
        

    

