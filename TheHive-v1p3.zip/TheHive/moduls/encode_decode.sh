#!/bin/bash 

#renk atamaları
red='\033[1;31m'
green='\033[1;32m'
yellow='\033[1;33m'
blue='\033[1;34m'
light_cyan='\033[1;96m'
reset='\033[0m'

base_64_coder () 
{
	while :
	do 
		clear 
		printf "${green}-Base64-\n"
		echo
		printf "1 - encode"
		echo 
		printf "2 - decode"
		echo
		echo
		printf "99 - Çıkış${reset}\n"
		echo
		echo "=============================="
		echo
		read -p "-İşlem-> " encode_or_decode
		
		if [[ "$encode_or_decode" = "1" ]] ; then
			clear 
			echo
			read -p "Metin -> " input_str
			echo
			echo "=============================="
			echo
			echo "$input_str" | base64  
			echo
			echo "=============================="
			echo
			read -p "Devam etmek için ENTER "
		elif [[ "$encode_or_decode" = "2" ]] ; then
			clear 
			echo
			read -p "Metin -> " input_str
			echo
			echo "=============================="
			echo
			echo "$input_str" | base64 -d 
			echo
			echo "=============================="
			echo
			read -p "Devam etmek içi ENTER "
		else 
			printf "${red}Çıkış yapılıyor...!${reset}\n"
			sleep 1
			break
		fi 
	
	done 
}

base_32_coder ()
{
	while :
	do 
		clear 
		printf "${green}-Base32-\n"
		echo
		printf "1 - Encode"
		echo
		printf "2 - Decode"
		echo
		printf "99 - Çıkış${reset}\n"
		echo
		echo "=============================="
		echo
		read -p "-İşlem-> " encode_or_decode
		if [[ "$encode_or_decode" = "1" ]] ; then
			clear 
			echo
			read -p "Metin -> " input_str
			echo
			echo "=============================="
			echo
			echo "$input_str" | base32  
			echo
			echo "=============================="
			echo
			read -p "Devam etmek için ENTER "
		elif [[ "$encode_or_decode" = "2" ]] ; then
			clear 
			echo
			read -p "Metin -> " input_str
			echo
			echo "=============================="
			echo
			echo "$input_str" | base32 -d 
			echo
			echo "=============================="
			echo
			read -p "Devam etmek içi ENTER "
		else 
			printf "${red}Çıkış yapılıyor...!${reset}\n"
			sleep 1
			break
		fi 
		
	done 
}


while :
do 
	clear 
	printf "${green}Seçim ypınız:\n"
	echo 
	printf "1 - Base64 encode/decode\n"
	printf "2 - Base32 encode/decode\n"
	echo
	echo 
	printf "99 - Çıkış${reset}\n"
	echo
	read -p "-İşlem->" selections
	
	if [[ "$selections" = "1" ]] ; then
		base_64_coder
	elif [[ "$selections" = "2" ]] ; then
		base_32_coder
	elif [[ "$selections" = "99" ]] ; then
		printf "${red}Çıkış yapılıyor...!${reset}\n"
		sleep 1
		break
	else 
		echo
		printf "${read}Bilinmeyen girdi...!${reset}\n"
		sleep 1
	fi 
	
done 
