clear
login_standart  () 
{	
	clear 
	red='\033[1;31m'
	green='\033[1;32m'
	yellow='\033[1;33m'
	blue='\033[1;34m'
	light_cyan='\033[1;96m'
	reset='\033[0m'
	printf "${red} ====================================================     \n"
	printf "${red} #####   #####  #####  ################### #########      \n"
	printf "${red} |###|   |###|  |###|   #################  ########	  \n"
	printf "${red} |###|   |###|  |###|    ###############   ###           \n"
	printf "${red} |###|   |###|  |###|	 ##############    ###		   \n"	
	printf "${red} |###|___|###|  |###|	  ############     ###_____ 	   \n"
	printf "${red} |###########|  |###|	   ##########      ########       \n"
	printf "${red} |###|   |###|  |###|       #TheHive#	   ########	   \n"
	printf "${red} |###|   |###|  |###|        #######	   ###             \n"
	printf "${red} |###|   |###|  |###|         ##### 	   ###___         \n"
	printf "${red} |###|   |###|  |###|	      #### 	   ###### 	    \n"
	printf "${red} #####   #####  #####	       ##	   ########${reset}\n"
	printf "${red} ===================================================${reset} \n"
	echo 
	printf "${green}	By @TheKoba\n\n${reset}"
}
login_standart	
red='\033[1;31m'
green='\033[1;32m'
yellow='\033[1;33m'
blue='\033[1;34m'
light_cyan='\033[1;96m'
reset='\033[0m'
echo "=============================="
echo 
printf "${green}Bu tool https://t.me/TheKoba tarafından yazılmıştır.\n${reset}"
echo 
printf "${green}Aynı zamanda MIT lisansı ile lisanslanmıştır.\n${reset}"
echo 
echo "=============================="
echo
sleep 1 
read -p "Devam etmek için ENTER"
