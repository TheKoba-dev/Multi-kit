#!/bin/bash
#if [[ ! -e "/usr/lib/sudo" ]]
#then
#    clear
#    echo "sudo bulunamadı işlem iptal ediliyor...!"
#    echo "Termux kullanıyorsanız---------------------"
#    echo "https://github.com/TheKoba-dev/Termux-toolkits toolunu kullanınız...!"
#    exit
#fi 



login_standart  () 
{	
	clear 
	red='\033[1;31m'
	green='\033[1;32m'
	yellow='\033[1;33m'
	blue='\033[1;34m'
	light_cyan='\033[1;96m'
	reset='\033[0m'
	printf "${red} ====================================================     \n"
	printf "${red} #####   #####  #####  ################### #########      \n"
	printf "${red} |###|   |###|  |###|   #################  ########	  \n"
	printf "${red} |###|   |###|  |###|    ###############   ###           \n"
	printf "${red} |###|   |###|  |###|	 ##############    ###		   \n"	
	printf "${red} |###|___|###|  |###|	  ############     ###_____ 	   \n"
	printf "${red} |###########|  |###|	   ##########      ########       \n"
	printf "${red} |###|   |###|  |###|       #TheHive#	   ########	   \n"
	printf "${red} |###|   |###|  |###|        #######	   ###             \n"
	printf "${red} |###|   |###|  |###|         ##### 	   ###___         \n"
	printf "${red} |###|   |###|  |###|	      #### 	   ###### 	    \n"
	printf "${red} #####   #####  #####	       ##	   ########${reset}\n"
	printf "${red} ===================================================${reset} \n"
	echo 
	printf "${green}	By @TheKoba\n\n${reset}"
	sleep 2
	clear
}
login_standart	
bash moduls/first_start.sh #kurulum kontrolu için düzenli olarak kontrol sağlar 
if [[ ! -d "$HOME/Hack-Tools/tmp" ]] #eğer geçici dizin tmp yi bulamazsa oluşturacak
then
	echo "tmp bulunamadı oluşturuluyor...!"
	mkdir $HOME/Hack-Tools/tmp
	sleep 1
fi 
rm -rf $HOME/Hack-Tools/tmp/* #kendi tmp dizinini düzenli olarak temizlemesi için
while :
do 
clear
echo "=============================="
echo ""
echo "	 - TheHive v1.0 -"
echo ""
echo "1 - Exiftool ile meta veri okuma"
echo "2 - Cupp ile wordlist oluştur"
echo "3 - IP-Tracer ile ip adresi takip et"
echo "4 - Netdiscover ile ağ içi arp taraması"
echo "5 - Nmap ile tarama"
echo "6 - Sistemi güncelle"
echo "7 - Bash shell başlat"
echo "8 - Metasploit-framework kur (GitHub)"
echo "9 - Msfvenom ile trojan oluştur"
echo "10- Phoneinfoga ile telefon sorgusu"
echo "11- Metin encode/decode"
echo ""
echo "97 - Log kayıtlarını sil..."
echo "98 - Yapımcı ve lisans bilgileri"
echo "99 - Çıkış"
echo "=============================="
echo ""
echo "Mevcut dizin -> $PWD"
echo "Home dizini -> $HOME"
echo ""
echo "=============================="
echo ""
read -p "-İşlem-> " main_select

if [[ "$main_select" = "1" ]] 
then 
    bash moduls/exiftool.sh

elif [[ "$main_select" = "2" ]]
then
    bash moduls/cupp.sh

elif [[ "$main_select" = "3" ]] 
then   
    bash moduls/ip_tracer.sh

elif [[ "$main_select" = "4" ]]
then
    bash moduls/netdiscover.sh

elif [[ "$main_select" = "5" ]] 
then
	bash moduls/nmap.sh

elif [[ "$main_select" = "6" ]]
then
	bash moduls/sys-update.sh

elif [[ "$main_select" = "7" ]]
then
	clear
	echo "=============================="
	echo
	echo "Tool manüsüne dönmek için exit yzmanız yeterli! "
	echo
	echo "=============================="
	echo
	read -p "Devam etmek için ENTER"
	clear
	bash
elif [[ "$main_select" = "8" ]]
then
	bash moduls/msf_install.sh 

elif [[ "$main_select" = "9" ]]
then
	bash moduls/msf_venom/msf_venom.sh 

elif [[ "$main_select" = "10" ]]
then
	bash moduls/phone_infoga.sh 

elif [[ "$main_select" = "11" ]]
then
	bash moduls/encode_decode.sh

elif [[ "$main_select" = "97" ]]
then
    bash moduls/terminate_log.sh 


elif [[ "$main_select" = "98" ]]
then
    bash moduls/lisans.sh

elif [[ "$main_select" = "99" ]]
then
    echo "Çıkış yapılıyor....!"
    sleep 1
    break
else 
    echo "Bilinmeyen girdi...!"
    sleep 1
    clear
fi 
done 
